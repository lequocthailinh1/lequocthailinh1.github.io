// Gọi header.html, footer.html, menu.html
$('#header').load('layout/header.html');
$('#footer').load('layout/footer.html');
$('#menu').load('layout/menu.html');